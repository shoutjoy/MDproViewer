# MDpro SQLite 설계 패키지 v3.0

## 포함 파일
- MDpro_SQLite_Database_Design_v3.docx: 상세 설계서
- MDpro_SQLite_Database_Design_v3.md: Markdown 원문
- MDpro_SQLite_schema_v3.sql: 전체 DDL, 인덱스, FTS5, trigger, view
- MDpro_SQLite_query_catalog_v3.sql: 주요 CRUD, transaction, search, sync, backup 쿼리
- MDpro_SQLite_empty_v3.sqlite: 스키마가 적용된 빈 데이터베이스
- validation_manifest.json: 생성 및 검증 결과
- storage_architecture.png, erd_overview_small.png: 설계 그림

## 검증 결과
- SQLite 3.46.1
- 일반 테이블 57개
- FTS5 가상 테이블 5개
- View 4개
- Trigger 15개
- Query prepare 87개, 실패 0개
- integrity_check: ok
- foreign key violation: 0
- 한국어 trigram 검색: 통과
